﻿function Update_geoGebra_classic {
$PName = "GeoGebra Classic"
Write-Host ""
# Überprüft ob GeoGebra 6 Installiert ist

$path1 = Test-Path "C:\Program Files (x86)\GeoGebra 5.0"
# Für Version 6
$path2 = Test-Path "C:\Program Files (x86)\GeoGebra Classic"


if ($path1 -or $path2) {

    if ($path1) {
        $PName = "GeoGebra"
        # Überprüft die Installierte Version von GeoGebra 5
        $LocalVersion = (Get-Item "C:\Program Files (x86)\GeoGebra 5.0\GeoGebra.exe" ).VersionInfo.ProductVersion
        Write-Host "$PName ist in Version 5 installiert"    
    }

    if ($path2) {
        $PName = "GeoGebra Classic"
        # Überprüft die Installierte Version von GeoGebra 6
        $LocalVersion = (Get-Item "C:\Program Files (x86)\GeoGebra Classic\GeoGebra.exe" ).VersionInfo.ProductVersion
        Write-Host "$PName ist in Version $localVersion installiert"
    }
    

    # Überprüft die aktuellste Version von GeoGebra 6
    $html = Invoke-WebRequest -Uri "https://download.geogebra.org/installers/6.0/" | Select-Object -ExpandProperty Content

    $new = $html -split "`n" | Where-Object { $_ -match "geogebra-windows-installer" } | Out-String
    # Filtert die Version aus dem HTML Code
    $pattern = '-6-0-(\d+)-0'
    $matches = [regex]::Matches($new, $pattern) | ForEach-Object {$_.Groups[1].Value}
    $HighVersion = ($matches | Measure-Object -Maximum).Maximum
    $LatestVersion = "6.0." + $HighVersion

    Write-Host "Die neuste Version von $PName ist aktuell $LatestVersion"

    echo "test"
    echo $LocalVersion

    # Überprüft ob ´GeoGebra 6 aktualisiert werden muss
    if ($LocalVersion -ne $LatestVersion) {

        if ($path1) {
            $PName = "GeoGebra"
            # Deinstalliert die Alte GeoGebra Version
            Write-Host "Die alte $PName Verison wird deinstalliert"
           $uninstallPath = "C:\Program Files (x86)\GeoGebra 5.0\uninstaller.exe" 

            if (Test-Path $uninstallPath) {
                Start-Process -Wait -FilePath $uninstallPath -ArgumentList "/S"
                Write-Host "GeoGebra has been uninstalled."
            } else {
                Write-Host "GeoGebra uninstaller not found. Please check the installation path."
            }

        }

        if ($path2) {
            $PName = "GeoGebra Classic"
            # Deinstalliert die Alte GeoGebra Classic Version
            Write-Host "Die alte $PName Verison wird deinstalliert"
            $programName = "GeoGebra Classic"
            $program = Get-WmiObject -Class Win32_Product | Where-Object { $_.Name -eq $programName }
            if ($program) {
                $program.Uninstall()
                Write-Host "Die alte Verison von GeoGebra Classic wurde deinstalliert!"
            } else {
                Write-Host "Die alte Version von GeoGebra Classic konnte nicht deeinstalliert werden"
            }
        }

        # Startet den Download von GeoGebra Classic
        Write-Host "Der downlaod von $PName wurde gestartet..."       
           
        $url = "https://download.geogebra.org/installers/6.0/GeoGebra-Windows-Installer-6-0-$HighVersion-0.msi"
        $destination = "$env:USERPROFILE\Downloads\GeoGebra-Windows-Installer-$LatestVersion.msi"
        Invoke-WebRequest -Uri $url -OutFile $destination
            
        # Startet die Installation von GeoGebra Classic
        Write-Host "Die Installation von $PName wurde gestartet..."
        $destination = "$env:USERPROFILE\Downloads\GeoGebra-Windows-Installer-6.0.$HighVersion.msi"
        Start-Process -FilePath "$destination" -ArgumentList "ALLUSERS=1 /qn" -Wait
        Write-Host "GeoGrabra Installation abgeschlossen"
        
    } else {
        Write-Host "$PName ist bereits aktuell in Version $LatestVersion"
    }
        
} else {
    Write-Host "$PName ist auf diesem System nicht installiert"
    
}
}

