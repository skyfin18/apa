function Update_filius {
$PName = "Filius"
Write-Host ""
# �berpr�ft ob Filius Installiert ist
if (Test-Path "C:\Program Files\filius\filius.exe") {
    Write-Host "Filius ist installiert"
    
    # �berpr�ft die Installierte Version von Filius 
    $LocalVersion = (Get-ItemProperty -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\Filius").DisplayVersion

    Write-Host "Filius ist in der Version: $LocalVersion installiert"
    
    # �berpr�ft die aktuellste Version von 7-Zip
    $html = Invoke-WebRequest -Uri "https://gitlab.com/filius1/filius/-/blob/master/Changelog.md" | Select-Object -ExpandProperty Content

    # Den regul�ren Ausdruck definieren, um die Version zu extrahieren
    $regex = '(?<=version\s)\d+\.\d+\.\d+'

    # Die �bereinstimmungen mit dem regul�ren Ausdruck suchen
    $matches = [regex]::Matches($html, $regex)

    # Die erste �bereinstimmung extrahieren
    $CurrentVersion = $matches[0].Value

    # Die extrahierte Version anzeigen
    Write-Host "Die aktuelle Version von Filius ist: $CurrentVersion"
       
    # �berpr�ft ob Filius aktualisiert werden muss
    if ($LocalVersion -ne $CurrentVersion) {

        echo "Der 'Downlaod von Filius wurde gestartet..."

        #$link_version = $CurrentVersion.Replace(".", "")    
        $url = "https://www.lernsoftware-filius.de/downloads/Setup/Filius-Setup_with-JRE-$CurrentVersion.exe"
     

        $destination = "$env:USERPROFILE\Downloads\filius-$CurrentVersion-win64.exe"

        Invoke-WebRequest -Uri $url -OutFile $destination

        echo "Der Installation von Filius wurde gestartet..."
        Start-Process -FilePath $destination -ArgumentList "/S" -Wait

        Write-Host "Filius wurde erfolgreich Installiert"
        
    } else {
        echo "Filius ist bereits aktuell in Version $currentVersion"
   }
   
} else {
    Write-Host "Filius ist nicht installiert."
}
}