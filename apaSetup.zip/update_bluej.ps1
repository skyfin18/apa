﻿function update_bluej {

    #TODO: check version with appwiz?

    # check if installed
    if (-not (Test-Path -Path "C:\Program Files\BlueJ\BlueJ.exe" -PathType Leaf)) {
        Write-Host "BlueJ Not installed, exiting"
        exit 0
    }

    # check if outdated
    # get local version
    $versionraw = (Get-Item "C:\Program Files\BlueJ\BlueJ.exe" | Select-Object -ExpandProperty VersionInfo | Select-Object "ProductVersionRaw").ProductVersionRaw 
    $installedVersion = "" + $versionraw.Major + $versionraw.Minor + $versionraw.Build
    Write-Host "Installed version is: $($installedVersion)"
    
    # get remote version
    $url = "https://www.bluej.org/versions.html"
    $html = Invoke-WebRequest  -UseBasicParsing -Uri $url | Select-Object -ExpandProperty Content

    $regexPattern = '<span class="version_number">\d.\d.\d</span>';
    $regexMatches = [regex]::Match($html, $regexPattern)
    $latestVersion = $regexMatches[0].Value.Substring($regexMatches[0].Value.IndexOf('>') + 1, ($regexMatches[0].Value.LastIndexOf('<') - $regexMatches[0].Value.IndexOf('>') - 1)).replace('.', '')
    Write-Host "Latest version is: $($latestVersion)"

    # compare
    if ($installedVersion -lt $latestVersion) {    
        Write-Host "Updating installed version"    
        # download latest
        # https://www.bluej.org/download/files/BlueJ-windows-XYZ.msi
        # just replace XYZ with the apropriate version number
        $url = "https://www.bluej.org/download/files/BlueJ-windows-$($latestVersion).msi"

        # set Download Destination Path
        $destination = "$env:USERPROFILE\Downloads\BlueJ-windows-$latestVersion.msi"

        # Download
        Invoke-WebRequest -Uri $url -OutFile $destination

        # Install
        # for arguments refer to: https://bluej.org/faq.html#faq_How_do_I_perform_a__silent_installation__on_Windows_
        Start-Process -wait -FilePath msiexec -ArgumentList /qn, /i, $destination, INSTALLMENUSHORTCUT=1, INSTALLDESKTOPSHORTCUT=1
    }
    else {
        Write-Host "Latest Version Installed"
    }


}