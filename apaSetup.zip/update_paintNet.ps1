﻿

$PName = "Paint.NET"
Write-Host ""
# Überprüft ob PaintNet Installiert ist
if (Test-Path "C:\Program Files\paint.net") {

    $LocalVersion = (Get-Item "C:\Program Files\paint.net\paintdotnet.exe" ).VersionInfo.ProductVersion

    Write-Host "$PName ist in Version: $LocalVersion installiert"

    # Überprüft die aktuellste Version von PaintNet
    $html = Invoke-WebRequest -Uri "https://www.dotpdn.com/downloads/pdn.html#google_vignette" | Select-Object -ExpandProperty Content

    # Definiere ein reguläres Ausdrucksmuster, um die Versionsnummer zu extrahieren
    $pattern = 'paint.net\s+(\d+\.\d+\.\d+)'

    # Suche nach Übereinstimmungen im HTML-Code
    $matches = [regex]::Matches($html, $pattern)

    # Überprüfe, ob Übereinstimmungen gefunden wurden
    if ($matches.Count -gt 0) {
        # Extrahiere die Versionsnummer aus der ersten Übereinstimmung
        $LatestVersion = $matches[0].Groups[1].Value
        Write-Host "Die aktuelle Version von $PName ist: $LatestVersion"
    } else {
        Write-Host "Keine Übereinstimmung gefunden."
    }

   

    $LocalVersion = $LocalVersion.Split(".")

    $LocalVersion = $LocalVersion[0] + ".0." + $LocalVersion[1]



    # Überprüft ob PaintNet aktualisiert werden muss
    if ($LocalVersion -ne $LatestVersion) {

        Write-Host "Der downlaod von $PName wurde gestartet..."
       
     

        $url = "https://github.com/paintdotnet/release/releases/download/v$LatestVersion/paint.net.$LatestVersion.winmsi.x64.zip"
        $destination = "$env:USERPROFILE\Downloads\$PName-$LatesVersion.zip"
        Invoke-WebRequest -Uri $url -OutFile $destination

        Expand-Archive -Path $destination -DestinationPath "$env:USERPROFILE\Downloads\" -Force

        Write-Host "Die Installation von $PName wurde gestartet..."
        Start-Process -FilePath "$env:USERPROFILE\Downloads\paint.net.$LatestVersion.winmsi.x64.msi" -ArgumentList "/qn DESKTOPSHORTCUT=0" -Wait


        Write-Host "$PName Installation abgeschlossen"
        
    } else {
        Write-Host "$PName ist bereits aktuell in Version $LatestVersion"
    }

} else {
    Write-Host "$PName ist nicht auf diesem System installiert"
}


