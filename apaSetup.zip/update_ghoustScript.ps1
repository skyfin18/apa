﻿# function update_ghoustScript {
$PName = "Ghoust-Script"
Write-Host

$x86 = $false
$x86Update = $false
$x64 = $false
$x64Update = $false

# Überprüft ob Ghoust-Script installiert ist und checkt die Architektur
if (Test-Path "C:\Program Files (x86)\gs") {
    $x86 = $true
}
if (Test-Path "C:\Program Files\gs") {
    $x64 = $true
}
if ($x86 -or $x64) {
    if ($x86 -and $x64) {
        Write-Host "$Pname ist in x86 und x64 installiert"
    }
    elseif ($x86) {
        Write-Host "$Pname ist in x86 installiert"
    }
    else {
        Write-Host "$Pname ist in x84 installiert"
    }
} else {
Write-Host "$PName ist nicht installiert."
}

# Überprüft die Installierte/n Version von Ghoust-Script
if ($x86) {
    $installedVersion86 = (Get-Item "C:\Program Files (x86)\gs\gs10.01.0\bin\gswin32.exe" ).VersionInfo.ProductVersion
    Write-Host "$PName x32 ist in Version $installedVersion86 installiert"
}
if ($x64) {
    $installedVersion64 = (Get-Item "C:\Program Files\gs\gs10.01.0\bin\gswin64.exe" ).VersionInfo.ProductVersion
    Write-Host "$PName x64 ist in Version $installedVersion64 installiert"
}

# Überprüft die Latest Version von Ghoust-Script
$html = Invoke-WebRequest -Uri "https://github.com/ArtifexSoftware/ghostpdl-downloads/releases" | Select-Object -ExpandProperty Content
$regexPattern = '(?<=Ghostscript/GhostPDL\s)\d+(\.\d+)+'
$latestVersion = [regex]::Match($html, $regexPattern).Value
Write-Host "Die Latest Version ist $latestVersion"

# Überprüft ob Ghoust-Script Aktualisiert werden muss
if ($x86 -and $installedVersion86 -ne $latestVersion) {
    Write-Host "$PName x86 muss aktualisiert werden"
}
else {
    $x86 = false
}

if ($x64 -and $installedVersion64 -ne $latestVersion) {
    Write-Host "$PName x64 muss aktualisiert werden"
} else {
    $x64 = false
}

if ($x86) {
    <#Write-Host "Der downlaod von $PName wurde gestartet..."
    $linkVersion = $latestVersion -replace "\."

    $url = "https://github.com/ArtifexSoftware/ghostpdl-downloads/releases/download/gs" + $linkVersion + "/gs" + $linkVersion + "w32.exe"
    $destination = "$env:USERPROFILE\Downloads\Ghoust-Script-$LatestVersion.exe"
    Write-Host "test"
    # Invoke-WebRequest -Uri $url -OutFile $destination
    Write-Host "Die Installation von $PName wurde gestartet..."
    Start-Process -FilePath $destination -ArgumentList "/qn /quiet /verysilent" -Wait

    Write-Host "$PName Installation abgeschlossen"#>
}





<#




    


    # Überprüft ob Ghoust-Script Aktualisiert werden muss
    if ($LocalVersion -ne $LatestVersion) {

        Write-Host "Der downlaod von $PName wurde gestartet..."
        $link_version = $LatestVersion.Replace(".", "")    
        $url = "https://www.Ghoust-Script.org/a/7z$link_Version-x64.exe"
        $destination = "$env:USERPROFILE\Downloads\7zip-$LatestVersion.exe"
        Invoke-WebRequest -Uri $url -OutFile $destination
        Write-Host "Die Installation von $PName wurde gestartet..."
        Start-Process -FilePath $destination -ArgumentList "/S" -Wait

        Write-Host "$PName Installation abgeschlossen"
        
    } else {
        echo "$PName ist bereits aktuell in Version $LatestVersion"
    }
   #>


# }
