﻿function update_7zip {
$PName = "7-Zip"
Write-Host 
# Überprüft ob 7 Zip Installiert ist
if (Test-Path "C:\Program Files\7-Zip\7z.exe") {
    # Überprüft die Installierte Version von 7-Zip
    $LocalVersion = (Get-Item "C:\Program Files\7-Zip\7z.exe" ).VersionInfo.ProductVersion
    Write-Host "$PName ist in Version $localVersion installiert"

    # Überprüft die aktuellste Version von 7-Zip
    $html = Invoke-WebRequest -Uri "https://www.7-zip.org/download.html" | Select-Object -ExpandProperty Content
    $LatestVersion = [regex]::Match($html, 'Download 7-Zip ([\d.]+)').Groups[1].Value
    
    Write-Host "Die neuste Version ist aktuell $LatestVersion"

    # Überprüft ob 7-Zip Aktualisiert werden muss
    if ($LocalVersion -ne $LatestVersion) {

        Write-Host "Der downlaod von $PName wurde gestartet..."
        $link_version = $LatestVersion.Replace(".", "")    
        $url = "https://www.7-zip.org/a/7z$link_Version-x64.exe"
        $destination = "$env:USERPROFILE\Downloads\7zip-$LatestVersion.exe"
        Invoke-WebRequest -Uri $url -OutFile $destination
        Write-Host "Die Installation von $PName wurde gestartet..."
        Start-Process -FilePath $destination -ArgumentList "/S" -Wait

        Write-Host "$PName Installation abgeschlossen"
        
    } else {
        echo "$PName ist bereits aktuell in Version $LatestVersion"
    }
   
} else {
    Write-Host "$PName ist nicht installiert."
}

}
