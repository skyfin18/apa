﻿ function Update_TeamViewer {
 
$PName = "TeamViewer"
Write-Host ""
# Überprüft ob TeamViewer Installiert ist:
$path = "C:\Program Files (x86)\$PName\TeamViewer.exe"

if (Test-Path $path) {
    
    $LocalVersion = (Get-Item "$path" ).VersionInfo.ProductVersion
   
    Write-Host "Die Installierte Version von $PName ist $LocalVersion"

    # Überprüft die aktuellste Version von TeamViewer 
    $html = Invoke-WebRequest -Uri "https://www.teamviewer.com/de/download/windows/" | Select-Object -ExpandProperty Content
    
    # Extrahiert die Version aus dem HTML Code
    $pattern = 'Aktuelle Version: <span data-dl-version-label>(.*?)<\/span>'
    $matches = [regex]::Match($html, $pattern)

    # Überprüft ob das Extrahieren erfolgreich war
    if ($matches.Success) {
        $currentVersion = $matches.Groups[1].Value
        Write-Host "Aktuelle Version: $currentVersion"
    } else {
        Write-Host "Aktuelle Version nicht gefunden."
    }

    # Kürzt die Verison
    $LocalVersion = ($LocalVersion  -split '\.')[0..2] -join '.'

    # Überprüft ob Update erforderlich
    if ($LocalVersion -ne $currentVersion) {
        Write-Host "Die Aktualisierung von $PName wurde gestartet!"

        $url = "https://download.teamviewer.com/download/TeamViewer_Host_Setup.exe"
        $destination = "$env:USERPROFILE\Downloads\TeamViewer-$CurrentVersion.exe"
        Invoke-WebRequest -Uri $url -OutFile $destination

        Start-Process -FilePath $destination -ArgumentList "/S" -Wait

        Write-Host "Die Aktualisierung von $PName wurde erfolgreich abgeschlossen"


    } else {
        Write-Host "TeamViewer ist auf dem neusten Stand, keine Aktalisierung verfügbar!"
    }

    
} else {
    Write-Host "TeamViewer ist nicht auf diesem System installiert!"
}

}

