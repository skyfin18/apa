# Imports
. "C:\script\APA AppAutoUpdate\Script\checkService.ps1"
. "C:\script\APA AppAutoUpdate\Script\convertVersion.ps1"



# Funktion zum �berpr�fen von Software
function checkSoftware
{

    # Define the program names
    $programNames = "7-Zip", "Audacity", "Filius", "VLC-Media Player", "TeamViewer", "Inkscape", "Java", "PDF24-Creator", "PaintNet", "Gimp"

    $applications = @(
    @{
        Name = "7-Zip"
        Path = "C:\Program Files\7-Zip\7z.exe"
        VersionUri = "https://www.7-zip.org/download.html"
        Position = 0
        regex = "Download 7-Zip ([\d.]+)"
        ConvertVersion = $false
        CheckIfInstalled = $false
        CheckLatestVersion = $false
    },
    @{
        Name = "Audacity"
        Path = "C:\Program Files\Audacity\Audacity.exe"
        VersionUri = "https://www.audacityteam.org"
        Position = 1
        regex = 'Latest version : (\d+\.\d+\.\d+)'
        ConvertVersion = $true
        CheckIfInstalled = $false
        CheckLatestVersion = $false
    },
    @{
        Name = "Filius"
        Path = "C:\Program Files\filius\filius.exe"
        VersionUri = "https://gitlab.com/filius1/filius/-/blob/master/Changelog.md"
        Position = 2
        regex = '(?<=version\s)\d+\.\d+\.\d+'
        ConvertVersion = $false
        CheckIfInstalled = $true
        CheckLatestVersion = $true
    },
    @{
        Name = "VLC-Media Player"
        Path = "C:\Program Files\VideoLAN\VLC\vlc.exe"
        VersionUri = "https://www.chip.de/downloads/VLC-player-64-Bit_53513913.html"
        Position = 3
        regex = 'VLC media player \(64 Bit\)\s+([\d.]+)'
        ConvertVersion = $true
        CheckIfInstalled = $false
        CheckLatestVersion = $false
    },
    @{
        Name = "TeamViewer"
        Path = "C:\Program Files (x86)\TeamViewer\TeamViewer.exe"
        VersionUri = "https://www.teamviewer.com/de/download/windows/"
        Position = 4
        regex = 'Aktuelle Version: <span data-dl-version-label>(.*?)<\/span>'
        ConvertVersion = $true
        CheckIfInstalled = $false
        CheckLatestVersion = $false
    },
    @{
        Name = "Inkscape"
        Path = "C:\Program Files\Inkscape\bin\inkscape.exe"
        VersionUri = "https://inkscape.org/release"
        Position = 5
        regex = '<title>Download Inkscape (\d+\.\d+) \| Inkscape<\/title>'
        ConvertVersion = $false
        CheckIfInstalled = $false
        CheckLatestVersion = $false
    },
    @{
        Name = "Java"
        Path = "C:\Program Files\Java"
        VersionUri = "https://www.chip.de/downloads/Java-Runtime-Environment-64-Bit_42224883.html"
        Position = 6
        regex = 'Java Runtime Environment \(64 Bit\) (\d+\.\d+) Update (\d+)'
        ConvertVersion = $false
        CheckIfInstalled = $true
        CheckLatestVersion = $true
    },
    @{
        Name = "PDF24-Creator"
        Path = "C:\Program Files\PDF24\pdf24.exe"
        VersionUri = "https://www.pdf24.org/de/"
        Position = 7
        regex = '(?<=<span>PDF24 Creator<\/span>\s+)<span>(\d+\.\d+\.\d+)<\/span>'
        ConvertVersion = $false
        CheckIfInstalled = $false
        CheckLatestVersion = $false
    },
    ,
    @{
        Name = "PaintNet"
        Path = "C:\Program Files\paint.net\paintdotnet.exe"
        VersionUri = "C:\Program Files\paint.net\paintdotnet.exe"
        Position = 8
        regex = '(?<=<span>PDF24 Creator<\/span>\s+)<span>(\d+\.\d+\.\d+)<\/span>'
        ConvertVersion = $true
        CheckIfInstalled = $false
        CheckLatestVersion = $true
    }
    )

    # Initialize the array to store custom objects
    $data = @()

    # Loop through program names and create custom objects
    foreach ($programName in $programNames)
    {
        $customObject = [PSCustomObject]@{
            Name = $programName
            status = $true
            installedVersion = 'Nicht installiert'
            latestVersion = 'Konnte nicht ermittelt werden'
        }
        $data += $customObject
    }

    # �berpr�fe die Anwendungen
    foreach ($app in $applications) {
        Write-Host $app.Name
        # �berpr�ft ob das Programm Installiert ist
        if (Test-Path $app.Path) {
            # Speichert die Installierte Version
            if ($app.CheckIfInstalled) {
                $installedVersion = checkIfInstalled -name $app.name
            } else {
                # �berpr�ft die Version von dem Programm
                $installedVersion = (Get-Item $app.Path).VersionInfo.ProductVersion
            }
            # Convertiert die Version
            if ($app.ConvertVersion) {
                $installedVersion = ConvertVersion -name $app.name -version $installedVersion
            }

            # Aktualisiert $Data
            $data[$app.Position].status = 'Installed'
            $data[$app.Position].installedVersion = $installedVersion
        }
        else
        {
            $data[$app.Position].status = 'Nicht installiert'
        }
        # �berpr�ft die Latest Version
        $html = $html = Invoke-WebRequest -Uri $app.VersionUri | Select-Object -ExpandProperty Content
        # Speichert die Latest Version
        if ($app.CheckLatestVersion) {
            Write-Host 'dsklafjsldk'
            $data[$app.Position].LatestVersion = getLatestVersion -name $app.name
        } else {
            # �berpr�ft die Version von dem Programm
            $data[$app.Position].LatestVersion = [regex]::Match($html, $app.regex).Groups[1].Value
        }
        # �berpr�ft ob ein Update verf�gbar ist
        if ($data[$app.Position].status -eq 'Nicht installiert'){
        } else {
            if ($installedVersion -ne  $data[$app.Position].LatestVersion){
                $data[$app.Position].status = 'Update verf�gbar'
            }
        }
        Write-Host 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'
        Write-Host $data[$app.Name]
    }

    #############################################################################################################

    #############################################################################################################
    <# # Gimp
    # �berpr�ft ob Gimp Installiert ist

    $gimpKeyPath = 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*'
    $gimpSubKey = Get-ItemProperty -Path $gimpKeyPath | Where-Object { $_.DisplayName -like 'GIMP*' }

    if ($gimpSubKey) {
        $GimpLocalVersion = $gimpSubKey.DisplayVersion
        Write-Host "GIMP ist aktuell in Version: $GimpLocalVersion installiert"

        $data[9].installedVersion = $installedVersion
        $data[9].status = 'Installed'
    } else {
        # If Not Installed
        $data[9].status = 'Nicht installiert'
    }
    $WebResponse = Invoke-WebRequest "https://www.gimp.org/downloads/"
    $gimpCurrentVersion = $WebResponse.ParsedHtml.getElementById('win-download-link').innerText

    # K�rzt den String auf die Versionsnummer
    $LatestVersion = [regex]::Match($gimpCurrentVersion, "\d+\.\d+\.\d+").Value


    Write-Host "Die LatestVersion von Gimp ist: $LatestVersion"


    Write-Host "Die Latest Version ist $LatestVersion"

    $data[9].latestVersion = $LatestVersion

    # �berpr�ft ob Inkscape Aktualisiert werden kann
    if ($data[9].status -eq 'Nicht installiert') {

    } else {
        if ($installedVersion -ne $LatestVersion) {
            $data[9].status = 'Update verf�gbar'
        }
    }#>
    #############################################################################################################


   # Write-Host $data
    return $data

}





