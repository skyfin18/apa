function runUpdateSelectedProgramm
{

    param (
        [string]$programmName, # Der Parameter, den Sie �bergeben m�chten
        [string]$latestVersion
    )

    $data = [PSCustomObject]@{
        name = "$programmName"
        statusbar = ""
        installedV = ""
        status = ""
    }

    # Startet die Aktualisierung von 7-Zip
    if ($programmName -eq '7-Zip')
    {
        $linkVersion = $latestVersion -replace '\.'
        $url = "https://www.7-zip.org/a/7z$linkVersion-x64.exe"
        $destination = "$env:USERPROFILE\Downloads\7zip-$latestVersion.exe"
        Invoke-WebRequest -Uri $url -OutFile $destination
        Start-Process -FilePath $destination -ArgumentList "/S" -Wait
        $data.statusbar = "Das Update f�r $programmName wurde erfolgreich durchgef�hrt..."
        $data.installedV = $latestVersion
        $data.status = "Update abgeschlossen"
    }

    # Startet die Aktualisierung von Audacity
    if ($programmName -eq 'Audacity')
    {
        $url = "https://github.com/audacity/audacity/releases/download/Audacity-$LatestVersion/audacity-win-$LatestVersion-x64.exe"
        $destination = "$env:USERPROFILE\Downloads\audacity-$LatestVersion.exe"
        Invoke-WebRequest -Uri $url -OutFile $destination
        Start-Process -FilePath $destination -ArgumentList /VERYSILENT  -Wait
        $data.statusbar = "Das Update f�r $programmName wurde erfolgreich durchgef�hrt..."
        $data.installedV = $latestVersion
        $data.status = "Update abgeschlossen"
    }

    # Startet die Aktualisierung von Filius
    if ($programmName -eq 'Filius')
    {
        $url = "https://www.lernsoftware-filius.de/downloads/Setup/Filius-Setup_with-JRE-$latestVersion.exe"
        $destination = "$env:USERPROFILE\Downloads\filius-$latestVersion.exe"
        Invoke-WebRequest -Uri $url -OutFile $destination
        Start-Process -FilePath $destination -ArgumentList "/S" -Wait
        $data.statusbar = "Das Update f�r $programmName wurde erfolgreich durchgef�hrt..."
        $data.installedV = $latestVersion
        $data.status = "Update abgeschlossen"
    }

    # Startet die Aktualisierung von VLC-Media Player
    if ($programmName -eq 'VLC-Media Player')
    {
        # Startet den Download von VLC-Media Player
        Write-Host "VLC Update gestartet"
        $url = "https://ftp.halifax.rwth-aachen.de/videolan/vlc/$latestVersion/win64/vlc-$latestVersion-win64.exe"
        $destination = "$env:USERPROFILE\Downloads\vlc-$latestVersion.exe"
        Invoke-WebRequest -Uri $url -OutFile $destination

        # Silent-Installation starten (auf deutsch)
        $installArguments = "/L=1031 /S"
        Start-Process -FilePath $destination -ArgumentList $installArguments -Wait
        $data.statusbar = "Das Update f�r $programmName wurde erfolgreich durchgef�hrt..."
        $data.installedV = $latestVersion
        $data.status = "Update abgeschlossen"
    }

    # Startet die Aktualisierung von TeamViewer
    if ($programmName -eq 'TeamViewer')
    {
        # Startet den Download von TeamViewer
        Write-Host "TeamViewer Update gestartet"
        $url = "https://download.teamviewer.com/download/TeamViewer_Host_Setup.exe"
        $destination = "$env:USERPROFILE\Downloads\TeamViewer-$latestVersion.exe"
        Invoke-WebRequest -Uri $url -OutFile $destination
        Start-Process -FilePath $destination -ArgumentList "/S" -Wait
        Write-Host "Die Aktualisierung von $PName wurde erfolgreich abgeschlossen"
        $data.statusbar = "Das Update f�r $programmName wurde erfolgreich durchgef�hrt..."
        $data.installedV = $latestVersion
        $data.status = "Update abgeschlossen"
    }

    # Startet die Aktualisierung von Inkscape
    if ($programmName -eq 'Inkscape')
    {
        # Startet den Download von Inkscape
        Write-Host "Inkscape Download gestartet"
        $url = "https://inkscape.org/gallery/item/42333/inkscape-1.3_2023-07-21_0e150ed6c4-x64_31XBEKV.msi"
        $destination = "$env:USERPROFILE\Downloads\Inkscape-$LatestVersion.msi"
        Invoke-WebRequest -Uri $url -OutFile $destination
        Write-Host "Inkscape Update gestartet"
        Start-Process -FilePath "$destination" -ArgumentList "/qn" -Wait
        Write-Host "Die Aktualisierung von $PName wurde erfolgreich abgeschlossen"
        $data.statusbar = "Das Update f�r $programmName wurde erfolgreich durchgef�hrt..."
        $data.installedV = $latestVersion
        $data.status = "Update abgeschlossen"
    }

    # Startet die Aktualisierung von Java
    if ($programmName -eq 'Java')
    {
        # Startet den Download von Java
        Write-Host "Der Download von Java wurde gestartet"
        $url = "https://javadl.oracle.com/webapps/download/AutoDL?BundleId=248774_8c876547113c4e4aab3c868e9e0ec572"
        $destination = "$env:USERPROFILE\Downloads\java-$LatestVersion.exe"
        Invoke-WebRequest -Uri $url -OutFile $destination
        Write-Host "Der Installation von Java wurde gestartet..."
        Start-Process -FilePath $destination -ArgumentList "/s" -Wait
        $data.statusbar = "Das Update f�r $programmName wurde erfolgreich durchgef�hrt..."
        $data.installedV = $latestVersion
        $data.status = "Update abgeschlossen"
    }

    # Startet die Aktualisierung von PDF24-Creator
    if ($programmName -eq 'PDF24-Creator')
    {
        # Startet den Download von PDF24-Creator
        Write-Host "Der Download von PDF24-Creator wurde gestartet"

        $url = "https://download.pdf24.org/pdf24-creator-$latestVersion-x64.exe"
        $destination = "$env:USERPROFILE\Downloads\pdf24-$latestVersion.exe"
        $argumente = "/VERYSILENT /NORESTART"

        Invoke-WebRequest -Uri $url -OutFile $destination
        Write-Host "Der Installation von PDF24-Creator wurde gestartet..."
        Start-Process -FilePath $destination -ArgumentList $argumente -Verb RunAs -PassThru

        $data.statusbar = "Das Update f�r $programmName wurde erfolgreich durchgef�hrt..."
        $data.installedV = $latestVersion
        $data.status = "Update abgeschlossen"
    }

    # Startet die Aktualisierung von PDF24-Creator
    if ($programmName -eq 'PaintNet')
    {
        # Startet den Download von PDF24-Creator
        Write-Host "Der Download von PaintNet wurde gestartet"
        $url = "https://github.com/paintdotnet/release/releases/download/v$LatestVersion/paint.net.$LatestVersion.winmsi.x64.zip"
        $destination = "$env:USERPROFILE\Downloads\$PName-$LatesVersion.zip"
        Invoke-WebRequest -Uri $url -OutFile $destination
        Expand-Archive -Path $destination -DestinationPath "$env:USERPROFILE\Downloads\" -Force
        Write-Host "Die Installation von PaintNet wurde gestartet..."
        Start-Process -FilePath "$env:USERPROFILE\Downloads\paint.net.$LatestVersion.winmsi.x64.msi" -ArgumentList "/qn DESKTOPSHORTCUT=0" -Wait

        $data.statusbar = "Das Update f�r $programmName wurde erfolgreich durchgef�hrt..."
        $data.installedV = $latestVersion
        $data.status = "Update abgeschlossen"
    }



    return $data

}