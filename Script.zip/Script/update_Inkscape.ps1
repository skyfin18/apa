﻿function Update_Inkscape {
$PName = "Inkscape"
Write-Host ""
# Überprüft ob Inkscape Installiert ist
if (Test-Path "C:\Program Files\Inkscape\bin") {

    # Überprüft die Installierte Version von Inkscape
    $LocalVersion = (Get-Item "C:\Program Files\Inkscape\bin\inkscape.exe" ).VersionInfo.ProductVersion

    Write-Host "$PName ist in Version $LocalVersion installiert"

    # Überprüft die aktuellste Version von Inkscape
    $html = Invoke-WebRequest -Uri "https://inkscape.org/release" | Select-Object -ExpandProperty Content

    $regex = "<title>Download Inkscape (\d+\.\d+\.\d+) \| Inkscape</title>"
    $match = [regex]::Match($html, $regex)

    if ($match.Success) {
        $LatestVersion = $match.Groups[1].Value
        Write-Host "Die neuste Version ist aktuell $LatestVersion"
    } else {
        Write-Host "Versionsnummer nicht gefunden"
    }

    # Überprüft ob Inkscape aktualisiert werden muss
    if ($LocalVersion -ne $LatestVersion) {

        # Startet den Download von Inkscape 
        Write-Host "Der downlaod von $PName wurde gestartet..."       
           
        $url = "https://inkscape.org/gallery/item/37366/inkscape-1.2.2_2022-12-09_732a01da63-x64.msi"
        $destination = "$env:USERPROFILE\Downloads\Inkscape-$LatestVersion.msi"
        Invoke-WebRequest -Uri $url -OutFile $destination
            
        # Startet die Installation von Inkscape
        Write-Host "Die Installation von $PName wurde gestartet..."
        
        Start-Process -FilePath "$destination" -ArgumentList "/qn" -Wait
        Write-Host "$PName Installation abgeschlossen"
        
    } else {
        Write-Host "$PName ist bereits aktuell in Version $LatestVersion"
    }
   
} else {
    Write-Host "$PName ist bereits aktuell in Version $LatestVersion"
    
}

}
